# Call Your Horse

**Easily call your horse with a goat horn whenever you need it**

_The horse can be anywhere, it always works to teleport it to you, even in unloaded chunks_

There's currently a bug, where if the horse you want to call is too far away it will be invisible after the teleport 

--> to fix that you have to **rejoin the game**

## How it works

**1.** Tame a horse

**2.** Give the horse any name

**3.** Hold any goat horn you want in your hand

**4.** Sneak and look at the horse for 4 seconds

**4.** You will then get a horn that looks enchanted and has the name of the horse

**5.** Whenever you use the horn, it will teleport to you

--> Only the owner of the horse can get the goat horn + use the goat horn to call the horse

---

Works for: horses, donkeys, llamas, mules, skeleton_horses, trader_llamas


---

## Datapack created by Jodek published on modrinth: https://modrinth.com/user/Jodek

<picture>
   <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/Mqxx/GitHub-Markdown/main/blockquotes/badge/light-theme/tip.svg">
  <img alt="Tip" src="https://raw.githubusercontent.com/Mqxx/GitHub-Markdown/main/blockquotes/badge/dark-theme/tip.svg">
 </picture><br>
 
Questions or issues? -> [discord server](https://discord.gg/z2n3qTzQY6) | _or create an issue on github_
