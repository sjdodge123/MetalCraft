Description:
	This datapack makes seeds, saplings, ... plant themselves automatically when dropped as a item

Installation:
	• I recommend to unzip / extract this datapack so you can change settings (Right click folder, select "Extract All", click ok)
	• https://minecraft.wiki/w/Tutorials/Installing_a_data_pack

Having Issues:
	• Ensure that the name of the folder containing this file is 'smart_seeds'.
	• Make sure the folder containing this file is directly in the datapack folder of your minecraft world
	• This datapack is designed for Minecraft 1.21 and may not work correctly in other versions.
	• This datapack does only affect vanilla items by default (Check settings)
	• Seed items might behave differently when on farmland
		· This will affect most crop farms and might affect other farms that use this setup
		· Refer to the 'Settings' section to learn how to disable this behavior



Settings:
	Note: Changing settings might require some command experience.
	First:
	• Go to the folder ...\smart_seeds\data\smart_seeds\function
	• Open the file tick.mcfunction using text editor for windows and TextEdit for Mac OS 
	  (or any other software if you know what your doing)

Changing the time it takes the item to be planted:
		•  navigate to the comment "# TIME SETTING"
		•  below this comment there are two lines containing "smart_seeds_age=".
		•  The first line is for items that should be planted quickly while the second line is for slower items
		•  Replace the value after "smart_seeds_age=" with the what you want
			Enter 1 less than you actually want (For example 9 instead of 10)
			· 1s is equal to 10
			· The value cant be less than 1
			· Really values could result in the item despawning before it beeing planted
			· This mean if you want 2s you should enter 19


Changing whether motions of affected item should be disabled:
		• Navigate to the comment "# MOTION SETTING"
		• Comment the next line by adding a '#' at the beginning of it to disable this functionality. To re-enable it, simply remove the '#'


Adding / removing affected items:
		Step 1:
		• Navigate the comment "#add tag to all seed items"
		• For each affected item there is a lines like this (replace ITEM_ID and TAG):
			execute as @e[type=item,nbt={Item:{id:"ITEM_ID"}},tag=!smart_seeds_ignore] run tag @s add TAG

			Builtin Tags:	smart_seeds_crop_item (on farmland)
					smart_seeds_sapling_item (on any type of dirt)
					smart_seeds_nether_wart_item (on soul sand)
					smart_seeds_cocoa_beans_item (next to jungle log)
					smart_seeds_chorus_item (on endstone)

			example for wheat: execute as @e[type=item,nbt={Item:{id:"minecraft:wheat_seeds"}},tag=!smart_seeds_ignore] run tag @s add smart_seeds_crop_item

		Step 2:
		• Navigate the comment "#place the corresponding block to the item"
		• For each affected item there is a lines like this (replace ITEM_ID, BLOCK_ID and Y_OFFSET):
			execute as @e[tag=smart_seeds_plant,nbt={Item:{id:"ITEM_ID"}}] at @s run setblock ~ ~Y_OFFSET ~ BLOCK_ID

			Y offset:	0.5 for plants on farmland, soul sand, etc.
					0 for plants on full blocks, like sapling on grass blocks
					It's different for block with multiple orientations like cocoa beans

			example for wheat: execute as @e[tag=smart_seeds_plant,nbt={Item:{id:"minecraft:wheat_seeds"}}] at @s run setblock ~ ~0.5 ~ minecraft:wheat



Download pages:
• Modrinth: 		https://modrinth.com/project/smart-seeds
• Curseforge: 		-
• Planet Minecraft:	-