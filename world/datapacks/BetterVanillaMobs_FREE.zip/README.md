# Better Vanilla Mobs
A Minecraft datapack to add more challenge with vanilla monsters, making them faster, stronger and smarter. New behaviors and skills are given randomly to the mobs. Sometimes, a powerful ALPHA mob apears.

# Requires 
- Minecraft 1.21.2+

# Use
1. Download the package
2. Copy/paste the entire "BetterVanillaMobs/" archive in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map as you always do.
4. Take a look at the options: /function fkbm:options/get

# Author
- Name: FunkyToc 
- Website: https://funkytoc.fr
- PMC: https://www.planetminecraft.com/member/funkytoc/
- Modrinth: https://modrinth.com/user/FunkyToc

# License
This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License: http://creativecommons.org/licenses/by-nc-nd/4.0/

# Thanks
My Patreons that buy me coffe every days.
My community wich reminds me that I'm lazy.
Minecraft community, that gives meaning to this project.
Life, to be.
