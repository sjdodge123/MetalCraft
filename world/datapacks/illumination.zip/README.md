# Illumination

<img align="right" width="120px" height="120px" src="https://cdn.modrinth.com/data/eVpI7fHt/a2629b8e18c030816d49acb192a2c66c2a3fd0df_96.webp" alt="Illumination Logo">

Illumination adds an enchantment that subtly brightens the player's helmet, illuminating their surroundings and offering improved visibility in dark environments. Never be left in the dark again!

[![Discord](https://img.shields.io/badge/Join%20our%20Discord-%235865F2.svg?style=for-the-badge&logo=discord&logoColor=white)](https://discord.gg/wgSCCaQN5W)
![Illumination Preview](https://cdn.modrinth.com/data/eVpI7fHt/images/1090d11d54cb684515105e0e6cb91ea09ea50358.webp)

## Installation

### Datapack
1. Download the Datapack.
2. Copy the .zip file into the datapacks folder which is located under `%APPDATA%\.minecraft\saves\<your-world-name>\datapacks` (under Windows).
Replace <your-world-name> correspondingly.
3. Reload the World or run the `/reload` command.

### Mod
1. Download the Mod.
2. Copy the downloaded `.jar` file into the mods folder which is located under `%APPDATA%\.minecraft\mods` (under Windows).
3. Reload the World or run the `/reload` command.


## Bug Reports and Feature Requests
If you found bugs or need support, contact us by joining [our discord server](https://discord.gg/wgSCCaQN5W).
